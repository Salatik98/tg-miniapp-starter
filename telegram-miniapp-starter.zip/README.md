# Telegram Mini App — самый быстрый старт

ЭтотStarter — простая веб-страница (HTML + JS), которая открывается внутри Telegram как мини‑апп и показывает данные пользователя, даёт примеры Main Button и Haptic Feedback.

## Быстрый запуск (без бэкенда)

### 1) Хостинг (GitHub Pages)
1. Создай публичный репозиторий, например `tg-miniapp-starter`.
2. Залей файлы из этой папки (index.html).
3. В настройках репозитория включи **Pages** → Deploy from branch → `main` / root.
4. Твой URL будет вида `https://USERNAME.github.io/tg-miniapp-starter/` (HTTPS обязателен).

> Можно использовать любой другой HTTPS‑хостинг: Netlify, Cloudflare Pages и т.д.

### 2) Создай бота
1. В Telegram найди **@BotFather** → `/newbot`, получи токен `123456:ABC...`.
2. Напиши своему боту `/start` в личке (чтобы появился `chat_id` в апдейтах).

### 3) Кнопка «Открыть мини‑апп»
Выполни в терминале (замени `<TOKEN>` и `<YOUR_PAGES_URL>`):

```bash
# Узнать chat_id (после того, как ты написал боту /start)
curl -s https://api.telegram.org/bot<TOKEN>/getUpdates

# Отправить сообщение с кнопкой Web App
curl -s -X POST "https://api.telegram.org/bot<TOKEN>/sendMessage"   -H "Content-Type: application/json"   -d '{
    "chat_id": "<CHAT_ID>",
    "text": "Открой мини‑апп:",
    "reply_markup": {
      "keyboard": [[
        { "text": "Открыть мини‑апп", "web_app": { "url": "<YOUR_PAGES_URL>" } }
      ]],
      "resize_keyboard": true
    }
  }'
```

Нажми кнопку в чате — мини‑апп откроется внутри Telegram.

### 4) Что внутри примера
- Читает `Telegram.WebApp.initDataUnsafe.user` и рендерит имя, username, id.
- Кнопка `Main Button` отправляет `sendData(...)` боту (как `web_app_data`). Для демо бэкенд не нужен, но твой бот может это обработать.
- Пример Haptic feedback (вибро на iOS/Android).

### Важно про безопасность
В этом быстром старте нет проверки подписи `initData` на сервере. Для продакшна **обязательно** сделай верификацию на своём бэкенде (например, Cloudflare Workers / Vercel). Документация: https://core.telegram.org/bots/webapps#validating-data-received-via-the-web-app
